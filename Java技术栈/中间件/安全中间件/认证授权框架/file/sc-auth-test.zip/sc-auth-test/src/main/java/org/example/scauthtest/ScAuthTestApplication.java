package org.example.scauthtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScAuthTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScAuthTestApplication.class, args);
    }

}

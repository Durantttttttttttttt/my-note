package org.example.scauthtest.demos;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

/**
 * 自定义令牌类，也是凭证
 */
public class DemoToken extends AbstractAuthenticationToken {

    //用户名称
    private String userName;
    //密码
    private String password;

    public DemoToken(Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
    }

    public DemoToken(Collection<? extends GrantedAuthority> authorities, String userName, String password) {
        super(authorities);
        this.userName = userName;
        this.password = password;
    }


    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public Object getPrincipal() {
        return null;
    }
}

package org.example.scauthtest.demos;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 认证提供者，提供认证，准备使用这个来进行认证，其中authenticate方法实施认证，supports方法判断是否支持这个认证
 */
public class DemoAuthProvider implements AuthenticationProvider {

    //模拟登陆用户信息数据
    private Map<String, String> map = new LinkedHashMap<>();

    public DemoAuthProvider() {
        map.put("zhangsan", "123456");
        map.put("lisi", "123456");
    }


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        DemoToken demoToken = (DemoToken)authentication;
        String userName = demoToken.getUserName();
        String password = demoToken.getPassword();
        String rawPass = map.get(userName);
        if (rawPass == null) {
            throw new BadCredentialsException("用户不存在");
        }

        if (!password.equals(rawPass)) {
            throw new BadCredentialsException("认证有误：令牌校验失败");
        }
        //创建一个新的认证对象返回，授权列表为空
        DemoToken authenticatedToken = new DemoToken(Collections.emptyList());
        authenticatedToken.setUserName(userName);
        authenticatedToken.setPassword(password);
        authenticatedToken.setAuthenticated(true);
        return authenticatedToken;
    }

    /**
     * 定义支持DemoToken认证，也就是支持这个令牌
     * @param authentication
     * @return
     */
    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.isAssignableFrom(DemoToken.class);
    }
}

package org.example.scauthtest.demos;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * 全局配置，配置的入口
 */
@EnableWebSecurity
public class DemoWebSecurityConfig extends WebSecurityConfigurerAdapter {
    //配置 HTTP 请求的安全策略，应用 DemoAuthConfigurer 配置类实例
    protected void configure(HttpSecurity http) throws Exception
    {
        http.csrf().disable()//禁用 CSRF 防护
                //应用 DemoAuthConfigurer 配置类
                .apply(new DemoAuthConfigurer<>())
                .and()
                .sessionManagement().disable(); //session
    }
    //配置认证 Builder，由其负责构造 AuthenticationManager 认证管理者实例
    //Builder 将构造 AuthenticationManager 实例，并且作为 HTTP 请求的共享对象存储
    //在代码中可以通过 http.getSharedObject(AuthenticationManager.class) 来获取管理者实例
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception
    {
        //认证管理器中加入自定义的 Provider 认证提供者实例
        auth.authenticationProvider(demoAuthProvider());
    }
    //自定义的认证提供者实例
    @Bean("demoAuthProvider" )
    protected DemoAuthProvider demoAuthProvider()
    {
        return new DemoAuthProvider();
    }
}

package org.example.scauthtest.demos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.SecurityBuilder;
import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.authentication.logout.LogoutFilter;

/**
 * 自定义的认证配置，将过滤器配置到认证管理者之中
 */
public class DemoAuthConfigurer<T extends DemoAuthConfigurer<T, B>, B extends HttpSecurityBuilder<B>> extends AbstractHttpConfigurer<T,B>
{

    private DemoAuthFilter authFilter = new DemoAuthFilter();

    @Override
    public void configure(B http) throws Exception {
        //获取 Spring Security 共享的 AuthenticationManager 认证管理者实例，默认的
        //将其设置到认证过滤器中，因为要用
        authFilter.setAuthenticationManager(http.getSharedObject(AuthenticationManager.class));
        DemoAuthFilter filter = postProcess(authFilter);
        //将过滤器加入 http 过滤处理责任链，退出过滤器之前
        http.addFilterBefore(filter, LogoutFilter.class);

    }
}

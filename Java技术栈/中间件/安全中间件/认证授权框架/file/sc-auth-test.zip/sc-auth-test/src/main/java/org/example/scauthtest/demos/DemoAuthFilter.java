package org.example.scauthtest.demos;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 过滤器，进行用户认证，判断是否放行
 */
public class DemoAuthFilter extends OncePerRequestFilter {

    private AuthenticationManager authenticationManager;
    private AuthenticationFailureHandler failureHandler = new DemoAuthFail();

    public AuthenticationManager getAuthenticationManager() {
        return authenticationManager;
    }

    public void setAuthenticationManager(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        AuthenticationException failed = null;
        try {
            String token = request.getHeader("Authentication");
            if (token == null || token.trim().isEmpty()) {
                failed = new AuthenticationServiceException("请求头中缺少认证信息");
                throw failed;
            }
            //因为传过来的Headers是Authentication xxxxx,xxxxx
            String[] parts = token.split(",");
            if (parts.length != 2) {
                failed = new AuthenticationServiceException("请求头认证消息格式错误");
                throw failed;
            }

            DemoToken demoToken = new DemoToken(null);
            demoToken.setUserName(parts[0]);
            demoToken.setPassword(parts[1]);
            //调用认证管理器进行认证，认证管理器通过认证提供器校验数据（认证提供器里面有认证方法）
            Authentication returnToken = this.getAuthenticationManager().authenticate(demoToken);
            boolean succeed = returnToken.isAuthenticated();
            if (succeed) {
                //认证成功
                SecurityContextHolder.getContext().setAuthentication(returnToken);
                filterChain.doFilter(request, response);
                return;
            }
        } catch (AuthenticationException e) {
            logger.error("认证有误", e);
            failed = e;
        } catch (Exception e) {
            logger.error("认证有误", e);
            failed = new AuthenticationServiceException("请求头认证消息格式错误", e);
        }
        SecurityContextHolder.clearContext();
        failureHandler.onAuthenticationFailure(request, response, failed);
    }
}

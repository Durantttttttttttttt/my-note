package org.example.scauthtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScAuthTestApplicationTests {

    @Test
    void contextLoads() {
    }

}

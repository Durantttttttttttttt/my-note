package org.example.sctest3.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.example.sctest3.mapper.UserMapper;
import org.example.sctest3.pojo.User;
import org.example.sctest3.service.IUserService;
import org.springframework.stereotype.Service;

@Service
public class IUserServiceImpl extends ServiceImpl<UserMapper, User>  implements IUserService  {
}

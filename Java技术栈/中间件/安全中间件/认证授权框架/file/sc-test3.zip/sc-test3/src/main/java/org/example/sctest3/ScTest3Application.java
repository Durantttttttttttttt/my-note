package org.example.sctest3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

@SpringBootApplication
public class ScTest3Application {

    public static void main(String[] args) {
        SpringApplication.run(ScTest3Application.class, args);
    }

}

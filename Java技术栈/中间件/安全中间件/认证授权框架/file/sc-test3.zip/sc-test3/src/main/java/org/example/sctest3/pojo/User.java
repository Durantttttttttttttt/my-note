package org.example.sctest3.pojo;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class User implements Serializable {
    private String id;
    private String username;
    private String password;
    private String phone;
    private Integer age;
    private LocalDateTime birth;
    private Integer enabled;
    private String auth;
}

package org.example.sctest3.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.example.sctest3.pojo.MyUserDetail;
import org.example.sctest3.pojo.User;
import org.example.sctest3.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 认证服务
 */
@Service
public class DemoAuthUserService implements UserDetailsService {


    @Autowired
    private IUserService userService;

    /**
     *装载系统配置的加密器，将用户信息返回出去，这里会自动进行密码比对
     */
    @Resource
    private PasswordEncoder passwordEncoder;
    @Override
    public UserDetails loadUserByUsername(String phone) throws UsernameNotFoundException {

        //查询用户
        User user = userService.getOne(new QueryWrapper<User>().eq("phone", phone));
        // 检查用户是否存在
        if (user == null) {
            throw new UsernameNotFoundException("没有用户！");
        }
        return new MyUserDetail(user);
    }
}

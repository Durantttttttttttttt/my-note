package org.example.sctest3.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.example.sctest3.pojo.User;

public interface IUserService extends IService<User> {

}

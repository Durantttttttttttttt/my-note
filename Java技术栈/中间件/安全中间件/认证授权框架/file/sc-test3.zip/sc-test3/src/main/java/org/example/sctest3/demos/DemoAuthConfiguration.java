package org.example.sctest3.demos;

import org.example.sctest3.service.impl.DemoAuthUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.logout.LogoutFilter;

/**
 * 配置过滤器
 */
public class DemoAuthConfiguration <T extends DemoAuthConfiguration<T, B>, B extends HttpSecurityBuilder<B>> extends AbstractHttpConfigurer<T,B> {

    //创建认证过滤器
    private DemoAuthFilter authFilter = new DemoAuthFilter();
    //注入全局 BCryptPasswordEncoder 加密器容器实例
    @Autowired
    private PasswordEncoder passwordEncoder;
    //注入数据源服务容器实例
    @Autowired
    private DemoAuthUserService demoUserAuthService;

    /**
     * 注入默认的提供者，由框架提供的daoAuthenticationProvider
     * @return
     * @throws Exception
     */
    @Bean("daoAuthenticationProvider")
    protected AuthenticationProvider daoAuthenticationProvider() throws Exception
    {
        //创建一个数据源提供者
        DaoAuthenticationProvider daoProvider = new DaoAuthenticationProvider();
        //设置加密器
        daoProvider.setPasswordEncoder(passwordEncoder);
        //设置自定义的用户数据源服务，要用这个认证的哦
        daoProvider.setUserDetailsService(demoUserAuthService);
        return daoProvider;
    }

    @Override
    public void configure(B http) throws Exception {
        //获取 Spring Security 共享的 AuthenticationManager 认证管理者实例
        //将其设置到认证过滤器
        authFilter.setAuthenticationManager(http.getSharedObject(AuthenticationManager.class));
        DemoAuthFilter filter = postProcess(authFilter);
        //将过滤器加入 http 过滤处理责任链
        http.addFilterBefore(filter, LogoutFilter.class);
    }
}

package org.example.sctest3.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;

@Data
@Builder
@AllArgsConstructor
public class MyUserDetail implements UserDetails, Serializable {

    private String phone;
    private String password;
    private String auth;
    private Integer enabled;
    private Collection<? extends GrantedAuthority> authorities; // 权限列表

    public MyUserDetail(User user) {
        this.phone = user.getPhone();
        this.password = user.getPassword();
        this.auth = user.getAuth();
        this.enabled = user.getEnabled();
    }

    public MyUserDetail() {
        this.authorities = Collections.emptyList();
    }

    // 从 auth 字符串构建权限列表
    public void buildAuthoritiesFromAuth() {
        if (auth != null && !auth.trim().isEmpty()) {
            this.authorities = Arrays.stream(auth.split(","))
                    .map(String::trim) // 去除多余空格
                    .map(SimpleGrantedAuthority::new) // 转换为 GrantedAuthority
                    .collect(Collectors.toList());
        } else {
            this.authorities = Collections.emptyList();
        }
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return "";
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled == 1;
    }
}

package org.example.sctest3.demos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * 全局配置，配置的入口
 */
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true) // 启用 @PreAuthorize
public class DemoWebSecurityConfig extends WebSecurityConfigurerAdapter {
    //配置 HTTP 请求的安全策略，应用 DemoAuthConfigurer 配置类实例,/login接口放行
    protected void configure(HttpSecurity http) throws Exception
    {
        http.csrf().disable()//禁用 CSRF 防护
                //应用 DemoAuthConfigurer 配置类
                .apply(new DemoAuthConfiguration<>())
                .and()
                .authorizeRequests()
                .antMatchers("/user/login").permitAll()
                .anyRequest().authenticated()
                .and()
                .sessionManagement().disable(); //session
    }

    /**
     * 配置认证管理器、密码加密器
     * 如果你的应用中需要在其他地方（比如自定义过滤器、服务类等）通过 @Autowired 注入 AuthenticationManager，则需要保留 @Bean 注解。
     * @return
     * @throws Exception
     */
    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    /**
     * 密码编码器
     * @return
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }



}
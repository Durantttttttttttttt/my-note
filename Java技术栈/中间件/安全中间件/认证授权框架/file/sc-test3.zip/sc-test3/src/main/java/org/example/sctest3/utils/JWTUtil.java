package org.example.sctest3.utils;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * @author pcc
 * @version 1.0.0
 * @description JWT工具类
 */
@Slf4j
public class JWTUtil {

    /**
     * 私人的salt
     */
    public static final String TOKEN_SECRET = "ebbing_auth_service_token_secret_key_363272470";

    public static PrivateKey privateKeyRSA;
    public static PublicKey publicKeyRSA;

    /**
     * 验证JWTtoken
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception{
        initKey();
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("name","cheng");

        // 使用SHA256生成一个JWT
        String tokenBySHA256 = getTokenBySHA256(map);
        // 验证SHA256的Token
        System.out.println("SHA256Toekn: "+verifyToken(tokenBySHA256, "SHA256"));

        // 使用RSA生成一个JWT
        String tokenByRSA = getTokenByRSA(map);
        // 验证RSA的Token
        System.out.println("RSAToken: "+verifyToken(tokenByRSA, "RSA"));

    }

    /**
     * 生成一个公钥和私钥
     * 该公钥/私钥用于RSA
     */
    public static void initKey() throws Exception{
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048); // 设置密钥长度
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        // 初始化公钥私钥
        publicKeyRSA = keyPair.getPublic();
        privateKeyRSA = keyPair.getPrivate();

    }


    /**
     * 使用SHA256进行加密，生成token
     * claims：传入载荷信息
     * @return
     */
    public static String getTokenBySHA256(Map<String, Object> claims){
        // 设置1小时到期
        long expirationTime = System.currentTimeMillis() + 3600_000;
        return Jwts.builder()
                .setClaims(claims)
                .setExpiration(new Date(expirationTime))
                .signWith(io.jsonwebtoken.SignatureAlgorithm.HS256, TOKEN_SECRET)
                .compact();
    }


    /**
     * 使用RSA对称加密
     * privateKey： 私钥
     * @return
     */
    public static String getTokenByRSA(Map<String, Object> claims){
        // 设置过期时间为一小时后
        long expirationTime = System.currentTimeMillis() + 3600_000;

        return Jwts.builder()
                .setClaims(claims)
                .setExpiration(new Date(expirationTime))
                // 使用 RSA 签名算法，并提供私钥进行签名
                .signWith(SignatureAlgorithm.RS256,privateKeyRSA)
                .compact();
    }

    /**
     * 根据签名类型对token进行验证
     * @param token
     * @param signType SHA256，RSA
     * @return
     */
    public static boolean verifyToken(String token,String signType){

        boolean verifyFlag=false;

        try{
            switch (signType) {
                case "SHA256":
                    verifyFlag = Jwts.parser().
                            setSigningKey(TOKEN_SECRET).
                            parseClaimsJws(token).
                            getBody().
                            getExpiration().after(new Date());
                    break;
                case "RSA":
                    verifyFlag= Jwts.parser().
                            setSigningKey(publicKeyRSA).
                            parseClaimsJws(token).
                            getBody().
                            getExpiration()
                            .after(new Date());
                    break;
                default:
                    log.error("签名类型错误");
                    verifyFlag = false;
                    break;
            }
        }
        catch (Exception e){
            log.info("Token验证失败，原因：{}",e.getMessage());
            return false;
        }finally{
            return verifyFlag;
        }

    }

    /**
     * 获取jwt中的负载信息
     */
    public static Map<String,Object> getClaims(String token){
        return Jwts.parser().
                setSigningKey(TOKEN_SECRET).
                parseClaimsJws(token).
                getBody();
    }

}
package org.example.sctest3.demos;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.sctest3.pojo.MyUserDetail;
import org.example.sctest3.pojo.Result;
import org.example.sctest3.utils.JWTUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * 过滤器
 */
public class DemoAuthFilter extends OncePerRequestFilter {

    private AuthenticationManager authenticationManager;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    public void setAuthenticationManager(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        if(request.getRequestURI().equals("/user/login")) {
            filterChain.doFilter(request, response);
            return;
        }
        //获取header中的jwt，然后解析jwt获取用户信息，构建用户数据MyUserDetail,令牌类判断
        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            sendErrorResponse(response, 401, "Authorization header missing or invalid");
            return;
        }
        String jwt = header.substring(7);
        String phone = (String) JWTUtil.getClaims(jwt).get("phone");
        String auth = (String) JWTUtil.getClaims(jwt).get("auth");
        String redisJwt = stringRedisTemplate.opsForValue().get(phone);
        if (!jwt.equals(redisJwt)) {
            sendErrorResponse(response, 401, "Invalid or expired token");
            return;
        }
        //构建会话对象，只存在于当前请求的生命周期内。
        MyUserDetail userDetail = MyUserDetail.builder()
                .phone(phone)
                .auth(auth)
                .enabled(1) // 默认启用
                .build();
        userDetail.buildAuthoritiesFromAuth(); // 解析 auth 为权限列表
        UsernamePasswordAuthenticationToken authToken =
                new UsernamePasswordAuthenticationToken(userDetail, null, userDetail.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(authToken);
        filterChain.doFilter(request, response);
    }

    private void sendErrorResponse(HttpServletResponse response, int code, String msg) throws IOException {
        response.setStatus(code);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        Result<Object> result = new Result<>(code, msg, null);
        response.getWriter().write(objectMapper.writeValueAsString(result));
    }
}

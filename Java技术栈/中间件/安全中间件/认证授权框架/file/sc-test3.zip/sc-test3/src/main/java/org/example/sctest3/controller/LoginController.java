package org.example.sctest3.controller;

import org.example.sctest3.utils.JWTUtil;
import org.example.sctest3.pojo.MyUserDetail;
import org.example.sctest3.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/user")
public class LoginController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    /**
     * 手机号登录认证
     * @param user
     * @return
     */
    @PostMapping("/login")
    public String login(@RequestBody User user) {
        //构建用户信息，然后调用认证服务,两个参数分别是主体和凭证
        UsernamePasswordAuthenticationToken userPasswordAuthenticationToken =
                new UsernamePasswordAuthenticationToken(user.getPhone(), user.getPassword());

        try {
            // 进行认证
            Authentication authenticate = authenticationManager.authenticate(userPasswordAuthenticationToken);
            MyUserDetail principal = (MyUserDetail) authenticate.getPrincipal();

            // 认证成功，生成 JWT
            Map<String, Object> claims = new HashMap<>();
            claims.put("phone", principal.getPhone()); // 可选，添加更多信息
            claims.put("auth", principal.getAuth());
            String jwt = JWTUtil.getTokenBySHA256(claims);
            stringRedisTemplate.opsForValue().set(principal.getPhone(), jwt, 3600, TimeUnit.SECONDS);
            return jwt;
        } catch (AuthenticationException e) {
            // 认证失败（密码错误或用户不存在）
            return "login failed: " + e.getMessage();
        }
    }

    @GetMapping("/hello")
    @PreAuthorize("hasAuthority('quanxian1')")
    public String hello() {
        return "hello";
    }
}

package org.example.sctest3.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.example.sctest3.pojo.User;

@Mapper
public interface UserMapper extends BaseMapper<User> {
}
